import React from "react";

function Footer() {
  return <div className="footer">Copyright ©YashPatel 2024</div>;
}

export default Footer;
