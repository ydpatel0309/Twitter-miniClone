import React from "react";

function ProfileAvatar() {
  return <div>ProfileAvatar</div>;
}

export default ProfileAvatar;
