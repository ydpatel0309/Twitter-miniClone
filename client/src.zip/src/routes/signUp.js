import React from "react";
import SignupBody from "../components/SignupBody";

function SignUp() {
  return (
    <>
      <SignupBody />
    </>
  );
}

export default SignUp;
